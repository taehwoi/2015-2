/** Source code example for "A Practical Introduction to Data
    Structures and Algorithm Analysis, 3rd Edition (Java)" 
    by Clifford A. Shaffer
    Copyright 2008-2011 by Clifford A. Shaffer
 */

/** Linked list implementation */
class SingleLinkedList<E> implements List<E> {
	private Link<E> head;         // Pointer to list header
	private Link<E> tail;         // Pointer to last element
	protected Link<E> curr;       // Access to current element
	int cnt;		      // Size of list

	/** Constructors */
	SingleLinkedList(int size) { this(); }   // Constructor -- Ignore size
	SingleLinkedList() {
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void insert(E item) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void append(E item) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public E remove() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void moveToStart() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void moveToEnd() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void prev() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void next() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int length() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int currPos() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void moveToPos(int pos) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public E getValue() {
		// TODO Auto-generated method stub
		return null;
	}


}