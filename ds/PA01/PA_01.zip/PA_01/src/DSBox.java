/**
 * Implement this class using SingleLinkedList
 * @author DMLab
 *
 */
public class DSBox {
	private SingleLinkedList<String> list;
	
	DSBox(){
	}
	
	/**
	 * 
	 * @param document
	 */
	public void submit(String document){
	}
	
	/**
	 * 
	 * @return
	 */
	public String get_top(){
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public String get_bottom(){
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public String view_top(){
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public String view_bottom(){
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public int size(){
		return 0;
	}
}
